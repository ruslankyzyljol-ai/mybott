BOT_TOKEN = "БУЛ_ЖЕРГЕ_ТОКЕНИҢДИ_ЖАЗ"
ADMIN_ID = 123456789

FOOTBALL_API = "БУЛ_ЖЕРГЕ_FOOTBALL_API_ЖАЗ"

CHANNEL_ID = "@profix_channel"

BOOKMAKERS = {
    "1win": {
        "name": "1Win",
        "emoji": "🏆",
        "link": "https://1win.kg",
        "promo": "WIN500",
        "bonus": "+200% биринчи депозитке"
    },
    "1xbet": {
        "name": "1xBet",
        "emoji": "⚡",
        "link": "https://1xbet.kg",
        "promo": "BET300",
        "bonus": "+130% биринчи депозитке"
    },
    "melbet": {
        "name": "Melbet",
        "emoji": "🎯",
        "link": "https://melbet.kg",
        "promo": "MEL200",
        "bonus": "+100% биринчи депозитке"
    }
}

VIP_REFERRAL_DAYS = {
    1: 3,
    3: 14,
    5: 30
}
